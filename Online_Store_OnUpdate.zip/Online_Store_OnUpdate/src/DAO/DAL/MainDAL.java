package DAO.DAL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DAO.DAOInterface;
import DBConnectivity.DBConnection;
import Model.Category;
import Model.OrderWiseShippingCharges;
import Model.Product;

public class MainDAL implements DAOInterface {

	@Override
	public List<Product> getAllProducts() throws SQLException {
		List<Product> products = new ArrayList<>();
		DBConnection db = new DBConnection();
		try {
			Connection cn = db.loadProperties();
			PreparedStatement statement = cn.prepareStatement("SELECT * FROM dmvp_products_");
			ResultSet resultSet = statement.executeQuery();
			System.out.println("hi");

			while (resultSet.next()) {
				System.out.println("hi-rs");
				String prodId = resultSet.getString("prod_id");
				String prodName = resultSet.getString("prod_name");
				int prodPrice = resultSet.getInt("prod_price");
				int prodGst = resultSet.getInt("prod_gst");
				String prodImage = resultSet.getString("prod_image");
				int prodCategoryId = resultSet.getInt("prod_category_id");

				Product product = new Product(prodId, prodName, prodPrice, prodGst, prodImage, prodCategoryId);

				products.add(product);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println(products);
		return products;
	}

	@Override
	public List<Category> getAllCategories() throws SQLException {
		List<Category> cart_category = new ArrayList<>();

		try {
			DBConnection db = new DBConnection();
			Connection con = db.loadProperties();
			String cart_Stmt = "select * from dmvp_products_category_";
			PreparedStatement ps = con.prepareStatement(cart_Stmt);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int prod_category_id = rs.getInt("prod_category_id");
				String prod_category_name = rs.getString("prod_category_name");
				cart_category.add(new Category(prod_category_id, prod_category_name));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cart_category;
	}

	@Override
	public List<Product> getAllProductsOfCatgeory(int category_selected, int minPrice, int maxPrice)
			throws SQLException {
		List<Product> categorical_products = new ArrayList<>();
		System.out.println("DAO" + category_selected);
		try {
			DBConnection db = new DBConnection();
			Connection con = db.loadProperties();
			String category_stmt = "select * from dmvp_products_ where prod_category_id = ? and prod_price between ? and ?";
			PreparedStatement ps = con.prepareStatement(category_stmt);
			ps.setInt(1, category_selected);
			ps.setInt(2, minPrice);
			ps.setInt(3, maxPrice);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				String prodId = rs.getString("prod_id");
				String prodName = rs.getString("prod_name");
				int prodPrice = rs.getInt("prod_price");
				int prodGst = rs.getInt("prod_gst");
				String prodImage = rs.getString("prod_image");
				int prodCategoryId = rs.getInt("prod_category_id");

				Product product = new Product(prodId, prodName, prodPrice, prodGst, prodImage, prodCategoryId);

				categorical_products.add(product);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return categorical_products;
	}

	@Override
	public List<OrderWiseShippingCharges> getShippingCharges(int productprice) throws SQLException {
		List<OrderWiseShippingCharges> shippingCharges = new ArrayList<>();

		try {
			DBConnection db = new DBConnection();
			Connection con = db.loadProperties();
			String query = "SELECT * FROM dmvp_ordervaluewiseshippingcharges_ WHERE orvl_from >= ? AND orvl_to <= ?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, productprice);
			ps.setInt(2, productprice);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				int orvl_shippingamount = rs.getInt("orvl_shippingamount");

				shippingCharges.add(new OrderWiseShippingCharges(orvl_shippingamount));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return shippingCharges;
	}

	@Override
	public boolean checkPinCode(String pinCode) {
		boolean pinCodeExists = false;

		try {
			DBConnection db = new DBConnection();
			Connection con = db.loadProperties();
			String query = "SELECT COUNT(*) FROM dmvp_ServiceableRegions_ WHERE srrg_pinfrom = ? OR srrg_pinto = ?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, Integer.parseInt(pinCode));
			ps.setInt(2, Integer.parseInt(pinCode));
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				int count = rs.getInt(1);
				pinCodeExists = count > 0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return pinCodeExists;
	}

}
