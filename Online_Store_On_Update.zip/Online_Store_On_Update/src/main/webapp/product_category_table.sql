create table products_category(prod_category_id int primary key,prod_category_name varchar(20));

insert into products_category values(1,'fruits');
insert into products_category values(2,'dairy');
insert into products_category values(3,'non veg');
insert into products_category values(4,'vegetables');

