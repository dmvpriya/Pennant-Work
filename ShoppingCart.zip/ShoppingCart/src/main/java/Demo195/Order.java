package Demo195;

public class Order {
	int oid;
	String oname;
	double ototal;
	int cid;

	public int getOid() {
		return oid;
	}

	public void setOid(int oid) {
		this.oid = oid;
	}

	public String getOname() {
		return oname;
	}

	public void setOname(String oname) {
		this.oname = oname;
	}

	public double getOtotal() {
		return ototal;
	}

	public void setOtotal(double ototal) {
		this.ototal = ototal;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}
}
