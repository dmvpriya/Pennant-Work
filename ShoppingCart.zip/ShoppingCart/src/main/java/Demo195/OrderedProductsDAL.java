package Demo195;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class OrderedProductsDAL {
	int insertorders(double totalPrice, CartList cartList, String u) throws SQLException {
		int oid = 0;
		try {

			int c = 0;
			ResultSet r1 = null;
			Connection conn1 = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training",
					"plf_training_admin", "pff123");
			String sql1 = "select cid from customer2003 where username=?";
			PreparedStatement st = conn1.prepareStatement(sql1);
			st.setString(1, u);
			r1 = st.executeQuery();
			if (r1.next()) {
				c = r1.getInt("cid");
			}
			int r2 = 0;
			List<ProductInfo> product = cartList.getAllProducts();
			oid = OIDGenerator.generateOID();
			Class.forName("org.postgresql.Driver");
			Connection conn = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training",
					"plf_training_admin", "pff123");
			String sql = "insert into orders2003 values(?,?,?,?)";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setInt(1, oid);
			stmt.setString(2, "order " + oid);
			stmt.setDouble(3, totalPrice);
			stmt.setInt(4, c);
			int r = stmt.executeUpdate();

			Connection conn2 = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training",
					"plf_training_admin", "pff123");

			String sql2 = "insert into ordered_products2003 values(?,?,?,?,?,?)";
			PreparedStatement stmt2 = conn.prepareStatement(sql2);
			for (int i = 0; i < product.size(); i++) {
				stmt2.setInt(1, oid);
				stmt2.setInt(2, product.get(i).getPid());
				stmt2.setInt(3, product.get(i).getQty());
				stmt2.setDouble(4, product.get(i).getPrice());
				stmt2.setString(5, product.get(i).getPname());
				stmt2.setDouble(6, product.get(i).getGst());
				r2 = stmt2.executeUpdate();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return oid;
	}
}