package DAO;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DBConnectivity.DBConnection;
import Model.Category;
import Model.OrderWiseShippingCharges;
import Model.Product;

public class MainDALSample {
	public List<Object> executeStoredProc(String servletName) {
		List<Object> data = new ArrayList<>();
		try {
			DBConnection db = new DBConnection();
			Connection con = db.loadProperties();
			CallableStatement statement = con.prepareCall("{CALL ExecuteOperations(?)}");
			statement.setString(1, servletName);
			statement.execute();

			ResultSet resultSet = (ResultSet) statement.getObject(1);
			if (servletName.equals("ProductServlet")) {
				data.addAll(processProductsResultSet(resultSet));
			} else if (servletName.equals("CategoryServlet")) {
				data.addAll(processCategoriesResultSet(resultSet));
			} else if (servletName.equals("CategoryProductServlet")) {
				data.addAll(processProductsListResultSet(resultSet));
			} else if (servletName.equals("ShippingServlet")) {
				data.addAll(processShippingChargesResultSet(resultSet));
			} else if (servletName.equals("PinCodeServlet")) {
				data.add(statement.getBoolean(5));
			} else {

			}
		} catch (SQLException e) {
			e.printStackTrace();

		}
		return data;
	}

	private List<Product> processProductsResultSet(ResultSet resultSet) throws SQLException {
		List<Product> products = new ArrayList<>();
		while (resultSet.next()) {

			String prodId = resultSet.getString("prod_id");
			String prodName = resultSet.getString("prod_name");
			int prodPrice = resultSet.getInt("prod_price");
			int prodGst = resultSet.getInt("prod_gst");
			String prodImage = resultSet.getString("prod_image");
			int prodCategoryId = resultSet.getInt("prod_category_id");

			Product product = new Product(prodId, prodName, prodPrice, prodGst, prodImage, prodCategoryId);
			products.add(product);
		}
		return products;
	}

	private List<Category> processCategoriesResultSet(ResultSet resultSet) throws SQLException {
		List<Category> categories = new ArrayList<>();
		while (resultSet.next()) {
			int categoryId = resultSet.getInt("prod_category_id");
			String categoryName = resultSet.getString("prod_category_name");
			categories.add(new Category(categoryId, categoryName));
		}
		return categories;
	}

	private List<Product> processProductsListResultSet(ResultSet resultSet) throws SQLException {
		List<Product> products = new ArrayList<>();
		while (resultSet.next()) {
			String prodId = resultSet.getString("prod_id");
			String prodName = resultSet.getString("prod_name");
			int prodPrice = resultSet.getInt("prod_price");
			int prodGst = resultSet.getInt("prod_gst");
			String prodImage = resultSet.getString("prod_image");
			int prodCategoryId = resultSet.getInt("prod_category_id");

			Product product = new Product(prodId, prodName, prodPrice, prodGst, prodImage, prodCategoryId);
			products.add(product);
		}
		return products;
	}

	private List<OrderWiseShippingCharges> processShippingChargesResultSet(ResultSet resultSet) throws SQLException {
		List<OrderWiseShippingCharges> shippingCharges = new ArrayList<>();
		while (resultSet.next()) {
			int orvlShippingAmount = resultSet.getInt("orvl_shippingamount");
			shippingCharges.add(new OrderWiseShippingCharges(orvlShippingAmount));
		}
		return shippingCharges;
	}
}
