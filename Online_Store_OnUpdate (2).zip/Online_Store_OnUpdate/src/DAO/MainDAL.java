package DAO;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import DBConnectivity.DBConnection;
import Model.Category;
import Model.OrderWiseShippingCharges;
import Model.Product;

public class MainDAL implements DAO {

	@Override
	public List<Product> getAllProducts() {
		List<Product> products = new ArrayList<>();
		DBConnection db = new DBConnection();
		try {
			Connection cn = db.loadProperties();
			CallableStatement statement = cn.prepareCall("{CALL GetAllProducts()}");
			ResultSet resultSet = statement.executeQuery();

			while (resultSet.next()) {
				String prodId = resultSet.getString("prod_id");
				String prodName = resultSet.getString("prod_name");
				int prodPrice = resultSet.getInt("prod_price");
				int prodGst = resultSet.getInt("prod_gst");
				String prodImage = resultSet.getString("prod_image");
				int prodCategoryId = resultSet.getInt("prod_category_id");

				Product product = new Product(prodId, prodName, prodPrice, prodGst, prodImage, prodCategoryId);
				products.add(product);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return products;
	}

	@Override
	public List<Category> getAllCategories() {
		List<Category> cartCategories = new ArrayList<>();

		try {
			DBConnection db = new DBConnection();
			Connection con = db.loadProperties();
			CallableStatement statement = con.prepareCall("{CALL GetAllCategories()}");
			ResultSet rs = statement.executeQuery();

			while (rs.next()) {
				int categoryId = rs.getInt("prod_category_id");
				String categoryName = rs.getString("prod_category_name");
				cartCategories.add(new Category(categoryId, categoryName));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cartCategories;
	}

	@Override
	public List<Product> getAllProductsOfCategory(int categorySelected, int minPrice, int maxPrice) {
		List<Product> categoricalProducts = new ArrayList<>();

		try {
			DBConnection db = new DBConnection();
			Connection con = db.loadProperties();
			CallableStatement statement = con.prepareCall("{CALL GetProductsByCategoryAndPriceRange(?, ?, ?)}");
			statement.setInt(1, categorySelected);
			statement.setInt(2, minPrice);
			statement.setInt(3, maxPrice);
			ResultSet rs = statement.executeQuery();

			while (rs.next()) {
				String prodId = rs.getString("prod_id");
				String prodName = rs.getString("prod_name");
				int prodPrice = rs.getInt("prod_price");
				int prodGst = rs.getInt("prod_gst");
				String prodImage = rs.getString("prod_image");
				int prodCategoryId = rs.getInt("prod_category_id");

				Product product = new Product(prodId, prodName, prodPrice, prodGst, prodImage, prodCategoryId);
				categoricalProducts.add(product);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return categoricalProducts;
	}

	@Override
	public List<OrderWiseShippingCharges> getShippingCharges(int productPrice) {
		List<OrderWiseShippingCharges> shippingCharges = new ArrayList<>();

		try {
			DBConnection db = new DBConnection();
			Connection con = db.loadProperties();
			CallableStatement statement = con.prepareCall("{CALL GetShippingChargesForProductPrice(?)}");
			statement.setInt(1, productPrice);
			ResultSet rs = statement.executeQuery();

			while (rs.next()) {
				int orvlShippingAmount = rs.getInt("orvl_shippingamount");
				shippingCharges.add(new OrderWiseShippingCharges(orvlShippingAmount));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return shippingCharges;
	}

	@Override
	public boolean checkPinCode(String pinCode) {
		boolean pinCodeExists = false;

		try {
			DBConnection db = new DBConnection();
			Connection con = db.loadProperties();
			CallableStatement statement = con.prepareCall("{? = CALL CheckPinCodeExists(?)}");
			statement.registerOutParameter(1, Types.BOOLEAN);
			statement.setInt(2, Integer.parseInt(pinCode));
			statement.execute();
			pinCodeExists = statement.getBoolean(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return pinCodeExists;
	}

}
