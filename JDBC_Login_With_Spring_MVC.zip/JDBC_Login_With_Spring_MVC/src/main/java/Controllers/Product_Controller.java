package Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import DAO.DALlogin;
import Models.Products;

@Controller
public class Product_Controller {

	@Autowired
	DALlogin dl;

	@RequestMapping(value = "/getProducts", method = RequestMethod.GET)
	public String getAllProducts(Model model) {
		List<Products> prods = dl.getProducts();

		model.addAttribute("productsList", prods);

		return "products";
	}

}
