package config;

import jakarta.servlet.ServletContextListener;

public class Log4jConfigListener implements ServletContextListener {

}
