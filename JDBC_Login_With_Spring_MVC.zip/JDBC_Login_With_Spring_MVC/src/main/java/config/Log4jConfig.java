package config;

public class Log4jConfig {

}
