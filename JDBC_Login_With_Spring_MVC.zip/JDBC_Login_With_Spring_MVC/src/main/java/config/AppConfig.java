package config;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
@ComponentScan(basePackages = { "Controllers", "Models", "DAO", "Mapper" })
public class AppConfig {

	private final String URL = "url";
	private final String USER = "username";
	private final String DRIVER = "driver";
	private final String PASSWORD = "password";
	private final String PROPERTY_FILE_PATH = "D:\\I184\\JDBC_Login_With_Spring_MVC\\src\\main\\webapp\\WEB-INF\\properties\\Db.properties";

	@Bean
	public DataSource dataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		Properties properties = new Properties();
		try (InputStream input = new FileInputStream(PROPERTY_FILE_PATH)) {
			System.out.println("hello");
			properties.load(input);
			System.out.println(properties.getProperty(DRIVER));
			dataSource.setDriverClassName(properties.getProperty(DRIVER));
			System.out.println(properties.getProperty(URL));
			dataSource.setUrl(properties.getProperty(URL));
			System.out.println(properties.getProperty(USER));
			dataSource.setUsername(properties.getProperty(USER));
			System.out.println(properties.getProperty(PASSWORD));
			dataSource.setPassword(properties.getProperty(PASSWORD));
		} catch (IOException e) {
			e.printStackTrace(); // Handle the exception appropriately
		}
		return dataSource;
	}
}
