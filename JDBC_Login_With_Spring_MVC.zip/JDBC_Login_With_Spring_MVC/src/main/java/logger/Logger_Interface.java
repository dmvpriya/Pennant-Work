package logger;

public interface Logger_Interface {

	void logInfo(String message);

	void logWarn(String message);

	void logDebug(String message);

	void logError(String message);
}
