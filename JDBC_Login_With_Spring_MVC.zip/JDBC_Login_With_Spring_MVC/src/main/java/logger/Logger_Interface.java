package logger;

public interface Logger_Interface {

	void info(String message);
}
