package DAO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class DALlogin implements DAO_Login {

	JdbcTemplate jt;

	@Autowired
	public DALlogin(javax.sql.DataSource dataSource) {
		jt = new JdbcTemplate(dataSource);
	}

	private final String SQL_GET_ALL = "select count(*) from i195_user_credentials where user_name=? and password=?";

	@Override
	public boolean LoginInfo(String username, String password) {
		System.out.println("dl");
		int count = jt.queryForObject(SQL_GET_ALL, Integer.class, username, password);
		if (count == 1) {
			return true;
		} else {
			return false;
		}
	}

}
