package DAO;

import org.springframework.stereotype.Component;

@Component
public interface DAO_Login {

	boolean LoginInfo(String username, String password);
}
