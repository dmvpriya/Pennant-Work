package Mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import Models.Products;

public class ProductMapper implements RowMapper {

	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub

		Products prod = new Products();
		prod.setProduct_id(rs.getString("prod_id"));
		prod.setProduct_name(rs.getString("prod_name"));
		prod.setProduct_price(rs.getInt("prod_price"));
		prod.setProduct_image(rs.getString("prod_image"));

		return prod;
	}

}
