package com.spring.orm.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.orm.model.dmvp_Courses_;
import com.spring.orm.model.dmvp_Students_;
import com.spring.orm.repository.CourseRepository;
import com.spring.orm.repository.StudentRepository;

@Service
public class Home_Service implements DAO {

	@Autowired
	private StudentRepository student_repo;

	@Autowired
	private CourseRepository course_repo;

	@Override
	public void addStudents(Integer s_id, String s_name, Integer s_age, Set<dmvp_Courses_> courses) {
		// TODO Auto-generated method stub
		dmvp_Students_ students = new dmvp_Students_();
		students.setStudent_id(s_id);
		students.setStudent_name(s_name);
		students.setStudent_age(s_age);
		students.setCourses(courses);

		student_repo.save(students);
	}

	@Override
	public void addCourses(Integer course_id, String course_name, Set<dmvp_Students_> students) {
		// TODO Auto-generated method stub
		dmvp_Courses_ courses = new dmvp_Courses_();
		courses.setCourse_id(course_id);
		courses.setCourse_name(course_name);
		courses.setStudents(students);
		course_repo.save(courses);

	}

	@Override
	public List<dmvp_Students_> getStudentsData() {
		// TODO Auto-generated method stub
		return student_repo.findAll();

	}

	@Override
	public List<dmvp_Courses_> getCoursesData() {
		// TODO Auto-generated method stub
		return course_repo.findAll();

	}

	public void addCourseToStudent(Integer studentId, Integer courseId) {
		dmvp_Students_ student = student_repo.findById(studentId).orElseThrow();
		dmvp_Courses_ course = course_repo.findById(courseId).orElseThrow();

		student.getCourses().add(course);
		student_repo.save(student);
	}

}