package com.spring.orm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.spring.orm.model.dmvp_Students_;

@Repository
public interface StudentRepository extends JpaRepository<dmvp_Students_, Integer> {

}
