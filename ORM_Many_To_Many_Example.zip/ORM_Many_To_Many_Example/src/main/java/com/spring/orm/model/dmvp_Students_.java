package com.spring.orm.model;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "dmvp_Students_")
public class dmvp_Students_ {

	@Id
	private Integer student_id;
	private String student_name;
	private Integer student_age;

	@ManyToMany
	@JoinTable(name = "dmvp_Students_Courses_ORM_", joinColumns = @JoinColumn(name = "student_id"), inverseJoinColumns = @JoinColumn(name = "course_id"))
	private Set<dmvp_Courses_> courses = new HashSet<>();

	public dmvp_Students_() {

	}

	public dmvp_Students_(Integer s_id, String s_name, Integer s_age) {
		student_id = s_id;
		student_name = s_name;
		student_age = s_age;

	}

	public Integer getStudent_id() {
		return student_id;
	}

	public void setStudent_id(Integer student_id) {
		this.student_id = student_id;
	}

	public String getStudent_name() {
		return student_name;
	}

	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}

	public Integer getStudent_age() {
		return student_age;
	}

	public void setStudent_age(Integer student_age) {
		this.student_age = student_age;
	}

	public Set<dmvp_Courses_> getCourses() {
		return courses;
	}

	public void setCourses(Set<dmvp_Courses_> courses) {
		this.courses = courses;
	}

}
