package com.spring.orm.model;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "dmvp_Courses_")
public class dmvp_Courses_ {

	@Id
	private Integer course_id;
	private String course_name;

	@ManyToMany(mappedBy = "courses")
	private Set<dmvp_Students_> students = new HashSet<>();

	public dmvp_Courses_() {

	}

	public dmvp_Courses_(Integer course_id, String course_name) {
		super();
		this.course_id = course_id;
		this.course_name = course_name;
	}

	public Integer getCourse_id() {
		return course_id;
	}

	public void setCourse_id(Integer course_id) {
		this.course_id = course_id;
	}

	public String getCourse_name() {
		return course_name;
	}

	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}

	public Set<dmvp_Students_> getStudents() {
		return students;
	}

	public void setStudents(Set<dmvp_Students_> students) {
		this.students = students;
	}

}
