package com.spring.orm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.spring.orm.model.dmvp_Courses_;

@Repository

public interface CourseRepository extends JpaRepository<dmvp_Courses_, Integer> {

}
