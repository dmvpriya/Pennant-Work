package com.spring.orm.service;

import java.util.List;
import java.util.Set;

import com.spring.orm.model.dmvp_Courses_;
import com.spring.orm.model.dmvp_Students_;

public interface DAO {
	void addStudents(Integer s_id, String s_name, Integer s_age, Set<dmvp_Courses_> courses);

	void addCourses(Integer course_id, String course_name, Set<dmvp_Students_> students);

	List<dmvp_Students_> getStudentsData();

	List<dmvp_Courses_> getCoursesData();

}
