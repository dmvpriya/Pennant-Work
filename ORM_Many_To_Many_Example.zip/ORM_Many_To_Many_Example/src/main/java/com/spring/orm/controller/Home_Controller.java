package com.spring.orm.controller;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.orm.model.dmvp_Courses_;
import com.spring.orm.model.dmvp_Students_;
import com.spring.orm.repository.CourseRepository;
import com.spring.orm.repository.StudentRepository;
import com.spring.orm.service.DAO;

@Controller

public class Home_Controller {

	@Autowired
	private DAO dao;

	@Autowired
	private StudentRepository student_repo;

	@Autowired
	private CourseRepository course_repo;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	private String displayFirstPage() {
		return "firstPage";
	}

	@RequestMapping(value = "/addStudent", method = RequestMethod.GET)
	private String displayStudent(Model model) {
		List<dmvp_Courses_> coursesData = dao.getCoursesData();
		model.addAttribute("courses", coursesData);
		return "student";
	}

	@RequestMapping(value = "/addCourse", method = RequestMethod.GET)
	private String displayCourse(Model model) {
		List<dmvp_Students_> studentsData = dao.getStudentsData();
		model.addAttribute("students", studentsData);
		return "courses";
	}

	@RequestMapping(value = "/viewData", method = { RequestMethod.GET, RequestMethod.POST })
	private String displayData() {

		return "redirect:/FormOutput";
	}

	@RequestMapping(value = "/StudentFormOutput", method = { RequestMethod.GET, RequestMethod.POST })
	private String displayviewDataS(@RequestParam("studentId") Integer student_id,
			@RequestParam("studentName") String student_name, @RequestParam("studentAge") Integer student_age,
			@RequestParam("courses") List<Integer> courseIds, Model model) {

		Set<dmvp_Courses_> courses = new HashSet<>(course_repo.findAllById(courseIds));

		dao.addStudents(student_id, student_name, student_age, courses);

		List<dmvp_Students_> studentsData = dao.getStudentsData();
		List<dmvp_Courses_> coursesData = dao.getCoursesData();

		model.addAttribute("students", studentsData);
		model.addAttribute("courses", coursesData);

		return "viewData";
	}

	@RequestMapping(value = "/CourseFormOutput", method = { RequestMethod.GET, RequestMethod.POST })
	private String displayviewDataC(@RequestParam("courseId") Integer course_id,
			@RequestParam("courseName") String course_name, @RequestParam("students") List<Integer> studentIds,
			Model model) {

		Set<dmvp_Students_> students = new HashSet<>(student_repo.findAllById(studentIds));

		dao.addCourses(course_id, course_name, students);

		List<dmvp_Students_> studentsData = dao.getStudentsData();
		List<dmvp_Courses_> coursesData = dao.getCoursesData();

		model.addAttribute("students", studentsData);
		model.addAttribute("courses", coursesData);

		return "viewData";
	}

	@RequestMapping(value = "/FormOutput", method = { RequestMethod.GET, RequestMethod.POST })
	private String displayviewData(Model model) {

		List<dmvp_Students_> studentsData = dao.getStudentsData();
		List<dmvp_Courses_> coursesData = dao.getCoursesData();

		model.addAttribute("students", studentsData);
		model.addAttribute("courses", coursesData);

		return "viewData";
	}

}
