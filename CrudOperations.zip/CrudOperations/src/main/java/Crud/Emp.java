package Crud;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Emp {
	public void getdata(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		EmpDB db = new EmpDB();
		List<Employee> list = db.getAllEmp();
		request.setAttribute("ed", list);
		request.getRequestDispatcher("Employees.jsp").forward(request, response);

	}

}
