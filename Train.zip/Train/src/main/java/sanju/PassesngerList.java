
package sanju;

import java.util.ArrayList;
import java.util.List;

public class PassesngerList {
	private List<Passenger> passengers;

	public PassesngerList() {
		passengers = new ArrayList<>();
	}

	public void addPassenger(Passenger passenger) {

		passengers.add(passenger);
	}

	public List<Passenger> getAllPassengers() {
		return passengers;
	}
}
