
package sanju;

import java.security.SecureRandom;

public class PnrGenerator {
	private static final SecureRandom random = new SecureRandom();

	public static int generatePnr() {
		// Generate a random number within the range of 100000 to 999999
		return 100000 + random.nextInt(900000);
	}
}
