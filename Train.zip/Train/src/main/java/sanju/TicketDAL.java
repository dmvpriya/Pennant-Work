
package sanju;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TicketDAL {
	public void insertTicket(Ticket ticket) throws ClassNotFoundException {
		// JDBC code to insert a ticket into the tickets7 table

		try {
			System.out.println("ticketdal");
			Class.forName("org.postgresql.Driver");
			Connection conn = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training",
					"plf_training_admin", "pff123");
			String sql = "insert into tickets7(ticket_no,ticket_pnr,ticket_travel_date,ticket_from,ticket_to,ticket_class,ticket_psnger_no) values(?,?,?,?,?,?,?)";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setInt(1, ticket.getTicketNo());
			stmt.setInt(2, ticket.getPnr());
			stmt.setDate(3, ticket.getTravelDate());
			stmt.setString(4, ticket.getFrom());
			stmt.setString(5, ticket.getTo());
			stmt.setString(6, ticket.getTicketClass());
			stmt.setInt(7, ticket.getPassengerNo());
			int result = stmt.executeUpdate(); // This should be executeUpdate() for INSERT statements

		} catch (SQLException e) {
			System.out.println("error");
			e.printStackTrace();
		}
	}
}
