
package sanju;

import java.util.ArrayList;
import java.util.List;

public class TrainsList {
	private List<Train> trains;

	public TrainsList() {
		trains = new ArrayList<>();
	}

	public void addTrain(Train train) {

		trains.add(train);
	}

	public List<Train> getAllTrains() {
		return trains;
	}
}
