
package sanju;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TrainsDAL {
	public TrainsList getAllTrains(String fromStationId, String toStationId) throws ClassNotFoundException {

		TrainsList trainList = new TrainsList();
		int fsid = Integer.parseInt(fromStationId);
		int tsid = Integer.parseInt(toStationId);
		System.out.println("trains dal");

		try {
			Class.forName("org.postgresql.Driver");
			Connection conn = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training",
					"plf_training_admin", "pff123");
			String sql = "SELECT t.train_id, t.train_name, s1.station_name AS from_station_name,s2.station_name AS to_station_name FROM trains7 t INNER JOIN tstop7 ts1 ON t.train_id = ts1.train_no INNER JOIN tstop7 ts2 ON t.train_id = ts2.train_no INNER JOIN station7 s1 ON ts1.station_id = s1.station_id INNER JOIN station7 s2 ON ts2.station_id = s2.station_id WHERE ts1.station_id = ? AND ts2.station_id = ?";

			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setInt(1, fsid);
			stmt.setInt(2, tsid);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				String trainId = rs.getString("train_id");
				String trainName = rs.getString("train_name");
				String from = rs.getString("from_station_name");
				String to = rs.getString("to_station_name");
				trainList.addTrain(new Train(trainId, trainName, from, to));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return trainList;
	}
}
