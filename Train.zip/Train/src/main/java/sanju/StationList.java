
package sanju;

import java.util.ArrayList;
import java.util.List;

public class StationList {
	private List<Station> stations;

	public StationList() {
		stations = new ArrayList<>();
	}

	public void addStation(Station station) {
		stations.add(station);
	}

	public List<Station> getAllStations() {
		return stations;
	}
}
