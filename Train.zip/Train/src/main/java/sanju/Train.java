
package sanju;

public class Train {
	private String trainId;
	private String trainName;
	private String from;
	private String to;

	public Train(String trainId, String trainName, String from, String to) {
		super();
		this.trainId = trainId;
		this.trainName = trainName;
		this.from = from;
		this.to = to;
	}

	public String getTrainId() {
		return trainId;
	}

	public void setTrainId(String trainId) {
		this.trainId = trainId;
	}

	public String getTrainName() {
		return trainName;
	}

	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

}
