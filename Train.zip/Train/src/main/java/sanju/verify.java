package sanju;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/verify")
public class verify extends HttpServlet {
	static Connection con = null;
	static PreparedStatement ps = null;
	static ResultSet rs = null;
	static RequestDispatcher rd = null;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String u = request.getParameter("uname");
		String p = request.getParameter("pass");

		try {
			Class.forName("org.postgresql.Driver");
			con = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training",
					"plf_training_admin", "pff123");
			String checkData = "select * from data187 where username=? and pass=?";
			ps = con.prepareStatement(checkData);
			ps.setString(1, u);
			ps.setString(2, p);

			rs = ps.executeQuery();

			if (rs.next()) {
				response.setContentType("text/plain");
				PrintWriter out = response.getWriter();
				try {
					out.println("book	.jsp");
				} finally {
					out.close();
				}
			} else {
				response.setContentType("text/plain");
				PrintWriter out = response.getWriter();
				try {
					out.println("error");
				} finally {
					out.close();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("error");
		}
	}
}
