
package sanju;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/booking")
public class BookingServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		System.out.println("booking sevlet");
		double fair = 0;
		String tname = request.getParameter("tno");
		String from = request.getParameter("from");
		String to = request.getParameter("to");
		String dateString = request.getParameter("date");
		Date date = Date.valueOf(dateString);
		String cls = request.getParameter("cls");
		int ticketNo;

		int tp = Integer.parseInt(request.getParameter("passengerCount"));
		System.out.println(tp);

		String[] pname = request.getParameterValues("pname");
		String[] pgen = request.getParameterValues("pgen");
		String[] page = request.getParameterValues("page");
		String[] ppref = request.getParameterValues("ppf");
		for (int i = 0; i < pname.length; i++)
			System.out.println(pname[i] + " " + pgen[i] + " " + page[i] + " " + ppref[i]);
		System.out.println(from + " " + to + " " + date + " " + cls);
		// Generate a PNR
		int pnr = PnrGenerator.generatePnr();
		ticketNo = TicketNoGenerator.generateTicketNo();
		session.setAttribute("ticketNo", ticketNo);

		// Create Ticket object

		Ticket ticket = new Ticket();
		ticket.setTicketNo(ticketNo);
		ticket.setPnr(pnr);
		ticket.setTravelDate(date);
		ticket.setFrom(from);
		ticket.setTo(to);
		ticket.setTicketClass(cls);
		ticket.setPassengerNo(tp);

		PassesngerList pl = new PassesngerList();
		for (int i = 0; i < pname.length; i++) {
			Passenger passenger = new Passenger();
			System.out.println(ticketNo);
			passenger.setTicketNo(ticketNo);
			passenger.setName(pname[i]);
			passenger.setAge(Integer.parseInt(page[i]));
			passenger.setGender(pgen[i]);
			passenger.setName(pname[i]);
			passenger.setBerth(ppref[i]);
			pl.addPassenger(passenger);
			System.out.println(pl);
		}

		PassengerDAL pd = new PassengerDAL();
		TicketDAL td = new TicketDAL();

		try {
			td.insertTicket(ticket);
			pd.insertPassenger(pl);
		} catch (ClassNotFoundException e) {
			System.out.println("book servlet error");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String f = request.getParameter("from");
		String t = request.getParameter("to");
		String tc = request.getParameter("cls");
		try {
			FairDAO fdao = new FairDAO();
			fdao.calcfair(pl, ticket, tname);
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("book servlet error");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.sendRedirect("final.jsp");
	}
}
