
package sanju;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class FairDAO {

	public void calcfair(PassesngerList passengerlist, Ticket ticket, String tname)
			throws ClassNotFoundException, SQLException {
		String tn = null;
		int fare = 0, d = 0, bf = 0;
		double tf = 0.0, s = 0.0;
		ArrayList<Integer> age = new ArrayList<>();
		ArrayList<String> gen = new ArrayList<>();
		ArrayList<String> pn = new ArrayList<>();
		ArrayList<Double> fp = new ArrayList<>();
		Class.forName("org.postgresql.Driver");
		int pnr = ticket.getPnr();
		int tckid = ticket.getTicketNo();
		int from = Integer.parseInt(ticket.getFrom());
		System.out.println(from);
		int to = Integer.parseInt(ticket.getTo());
		System.out.println(to);
		String tclass = ticket.getTicketClass();
		System.out.println("ticket id:" + tckid + " form:" + from + " to:" + to + " tclass:" + tclass);
		String fst = null, tst = null;

		Connection c0 = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training",
				"plf_training_admin", "pff123");
		String s0 = "select train_name from trains7 where train_id=?";
		PreparedStatement st0 = c0.prepareStatement(s0);

		st0.setInt(1, Integer.parseInt(tname));
		ResultSet r0 = st0.executeQuery();
		if (r0.next()) {
			tn = r0.getString("train_name");
		}

		Connection conn0 = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training",
				"plf_training_admin", "pff123");
		String sql0 = "select station_name from station7 where station_id=?";
		PreparedStatement stmt0 = conn0.prepareStatement(sql0);

		stmt0.setInt(1, from);
		ResultSet rs0 = stmt0.executeQuery();
		if (rs0.next()) {
			fst = rs0.getString("station_name");
		}
		Connection conn11 = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training",
				"plf_training_admin", "pff123");
		String sql11 = "select station_name from station7 where station_id=?";
		PreparedStatement stmt11 = conn0.prepareStatement(sql11);
		stmt11.setInt(1, to);

		ResultSet rs11 = stmt11.executeQuery();
		if (rs11.next()) {
			tst = rs11.getString("station_name");
		}
		Connection conn = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training",
				"plf_training_admin", "pff123");
		String sql = "select fare from trainclass where classname=?";
		PreparedStatement stmt = conn.prepareStatement(sql);

		stmt.setString(1, tclass);
		ResultSet rs = stmt.executeQuery();
		if (rs.next()) {
			fare = rs.getInt("fare");
			System.out.println("fare:" + fare);
		}
		Connection conn1 = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training",
				"plf_training_admin", "pff123");
		String sql1 = "select distance from stationdistances where froms=? and tos=?";
		PreparedStatement stmt1 = conn1.prepareStatement(sql1);
		stmt1.setString(1, fst);
		stmt1.setString(2, tst);
		ResultSet rs1 = stmt1.executeQuery();

		if (rs1.next()) {
			d = rs1.getInt("distance");
			System.out.println("distance:" + d);
		}
		Connection conn2 = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training",
				"plf_training_admin", "pff123");
		String sql2 = "select basefare from fairs7 where distance=?";
		PreparedStatement stmt2 = conn2.prepareStatement(sql2);
		stmt2.setInt(1, d);
		ResultSet rs2 = stmt2.executeQuery();

		if (rs2.next()) {
			bf = rs2.getInt("basefare");
			System.out.println("basefare:" + bf);
		}
		tf = bf * fare;
		System.out.println("total fare:" + tf);
		Connection conn3 = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training",
				"plf_training_admin", "pff123");
		String sql3 = "select pname,page,pgen from passengers7 where ticket_no=?";
		PreparedStatement stmt3 = conn3.prepareStatement(sql3);
		stmt3.setInt(1, tckid);
		ResultSet rs3 = stmt3.executeQuery();
		while (rs3.next()) {
			pn.add(rs3.getString("pname"));
			age.add(rs3.getInt("page"));
			gen.add(rs3.getString("pgen"));
		}
		System.out.println(pn.size() + " " + age.size() + " " + gen.size());
		for (int i = 0; i < pn.size(); i++) {
			if (gen.get(i).equals("Male")) {
				System.out.println("gender male");
				if (age.get(i) >= 60) {
					System.out.println("age >= 60");
					fp.add(tf - (tf * 0.4));
					s += fp.get(i);
					System.out.println("fair pass:" + fp + " sum:" + s);
				} else {
					System.out.println("age < 60");
					fp.add(tf);
					s += fp.get(i);
					System.out.println("fair pass:" + fp + " sum:" + s);
				}
			} else if (gen.get(i).equals("Female")) {
				System.out.println("gender female");
				if (age.get(i) >= 58) {
					System.out.println("age >= 58");
					fp.add(tf - (tf * 0.5));
					s += fp.get(i);
					System.out.println("fair pass:" + fp + " sum:" + s);
				} else {
					System.out.println("age < 58");
					fp.add(tf);
					s += fp.get(i);
					System.out.println("fair pass:" + fp + " sum:" + s);
				}
			} else {
				System.out.println("gender male or female");
				fp.add(tf);
				s += fp.get(i);
				System.out.println("fair pass:" + fp + " sum:" + s);
			}
		}
		System.out.println("updta pprice passengers");
		Connection conn4 = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training",
				"plf_training_admin", "pff123");
		String sql4 = "UPDATE passengers7 SET pprice = ? WHERE pname = ?";
		PreparedStatement stmt4 = conn4.prepareStatement(sql4);
		int rs4;
		for (int i = 0; i < age.size(); i++) {
			stmt4.setDouble(1, fp.get(i));
			stmt4.setString(2, pn.get(i));
			rs4 = stmt4.executeUpdate();
			if (rs4 > 0) {
				System.out.println("passengers price " + rs4);
			}
		}
		Connection conn5 = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training",
				"plf_training_admin", "pff123");
		String sql5 = "UPDATE tickets7 SET ticket_total = ?,tname=?,tfrom=?,tto=? WHERE ticket_no = ?";
		PreparedStatement stmt5 = conn5.prepareStatement(sql5);
		int rs5;
		stmt5.setDouble(1, s);
		stmt5.setString(2, tn);
		stmt5.setString(3, fst);
		stmt5.setString(4, tst);
		stmt5.setInt(5, tckid);
		rs5 = stmt5.executeUpdate();
		if (rs5 > 0) {
			System.out.println("total price " + rs5);
		}

	}

}
