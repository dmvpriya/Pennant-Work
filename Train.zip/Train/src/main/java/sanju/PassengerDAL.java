
package sanju;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

public class PassengerDAL {
	public void insertPassenger(PassesngerList passengerlist) throws ClassNotFoundException {
		// JDBC code to insert a ticket into the tickets7 table

		try {
			List<Passenger> pob = passengerlist.getAllPassengers();
			Class.forName("org.postgresql.Driver");
			Connection conn = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training",
					"plf_training_admin", "pff123");
			String sql = "insert into passengers7(ticket_no,pname,page,pgen,pberth) values(?,?,?,?,?)";
			PreparedStatement stmt = conn.prepareStatement(sql);
			for (int i = 0; i < pob.size(); i++) {
				stmt.setInt(1, pob.get(i).getTicketNo());
				stmt.setString(2, pob.get(i).getName());
				stmt.setInt(3, pob.get(i).getAge());
				stmt.setString(4, pob.get(i).getGender());
				stmt.setString(5, pob.get(i).getBerth());
				System.out.println(pob.get(i).getName() + " " + pob.get(i).getAge() + " " + pob.get(i).getGender() + " "
						+ pob.get(i).getBerth());
				int result = stmt.executeUpdate();
			}

		} catch (SQLException e) {
			System.out.println("error");
			e.printStackTrace();
		}
	}
}
