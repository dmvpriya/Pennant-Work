
package sanju;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/trainServlet")
public class TrainServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		String fromStationId = request.getParameter("from");
		String toStationId = request.getParameter("to");

		if (fromStationId == null || toStationId == null || fromStationId.isEmpty() || toStationId.isEmpty()) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing parameters: from or to");
			return;
		}

		System.out.println(fromStationId + " " + toStationId);
		try {
			TrainsDAL trainsDAL = new TrainsDAL();
			TrainsList trains = trainsDAL.getAllTrains(fromStationId, toStationId);
			PrintWriter out = response.getWriter();
			StringBuilder options = new StringBuilder();
			for (Train train : trains.getAllTrains()) {
				options.append("<option value=\"").append(train.getTrainId()).append("\">").append(train.getTrainName())
						.append("</option>");
			}
			out.print(options.toString());
		} catch (Exception e) {
			e.printStackTrace(); // Proper error handling should be implemented
		}
	}

}
