
package sanju;

import java.security.SecureRandom;

public class TicketNoGenerator {

	private static final SecureRandom random = new SecureRandom();

	public static int generateTicketNo() {
		// Generate a random ticket number in the range 10000 to 99999
		return 100000 + random.nextInt(900000);
	}
}
