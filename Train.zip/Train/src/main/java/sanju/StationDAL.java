
package sanju;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StationDAL {

	public StationList getAllStations() throws ClassNotFoundException {
		StationList stationList = new StationList();
		try {
			System.out.println("station dal");
			Class.forName("org.postgresql.Driver");
			Connection conn = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/plf_training",
					"plf_training_admin", "pff123");
			PreparedStatement stmt = conn.prepareStatement("SELECT station_id, station_name FROM station7");
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				String stationId = rs.getString("station_id");
				String stationName = rs.getString("station_name");
				stationList.addStation(new Station(stationId, stationName));

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return stationList;
	}
}
