
package sanju;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/cat")
public class StationServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8"); // Set the response content type
		System.out.println("station servlet");
		PrintWriter out = response.getWriter();
		try {
			StationDAL stationDAL = new StationDAL();
			StationList stationList = stationDAL.getAllStations();

			StringBuilder options = new StringBuilder();
			for (Station station : stationList.getAllStations()) {
				options.append("<option value=\"").append(station.getStationId()).append("\">")
						.append(station.getStationName()).append("</option>");
			}
			out.print(options.toString());
		} catch (ClassNotFoundException e) {
			out.println("<option value='error'>Unable to load data</option>"); // Inform the client about the error in a
																				// user-friendly way
			log("Error in StationServlet: ", e); // Proper logging of the error
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR); // Set error status code
		} finally {
			out.close(); // Ensure to close the PrintWriter
		}
	}
}
