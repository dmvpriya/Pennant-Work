package DAO;

public interface DAOInterface {
	public void getData();
}
