create table hsn_codes(hsn_code varchar(10) primary key,gst int);

insert into hsn_codes values('ABC01',25);
insert into hsn_codes values('ABC02',10);
insert into hsn_codes values('ABC03',4);
insert into hsn_codes values('ABC04',3);
insert into hsn_codes values('ABC05',12);
insert into hsn_codes values('ABC06',7);
insert into hsn_codes values('ABC07',9);
insert into hsn_codes values('ABC08',5);
insert into hsn_codes values('ABC09',12);
insert into hsn_codes values('ABC10',20);